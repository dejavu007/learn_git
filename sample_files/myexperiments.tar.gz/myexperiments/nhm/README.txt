This module is to make small custom tweaks for Naya Hindi Movies

If any dependencies are required need to be added in nhm.info file.


List of custom tweaks.
*