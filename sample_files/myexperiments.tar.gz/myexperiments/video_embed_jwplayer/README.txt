This module is to add jw player field format option for video embed field. It works for youtube url's only.
