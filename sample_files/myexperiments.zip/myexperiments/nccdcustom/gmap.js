  var map;
  var markers = [];
  var allMarkers = [];
  var organizations = false;
  var zIndex = false;
  var highestZIndex = 0;
  var tempZIndex;
  var filterXHR = null;
  var disableHover = false;
  var popupcontent = document.createElement("DIV");
  popupcontent.className = "organization-details";
  popupcontent.style.width="150px";
  var title = document.createElement("DIV");
  title.className = "organization-title";
  popupcontent.appendChild(title);
  var info = document.createElement("DIV");
  info.className = "organization-info";
  popupcontent.appendChild(info);
  var infowindow = new google.maps.InfoWindow({
    content: popupcontent,
	maxWidth: 150
  });

  function initialize() {
    var centerLatlng = new google.maps.LatLng(42.2839714, -71.3475892);
    if(!!jQuery('#ajax-organizations table tr').offset()){
	  locations = [];
	  jQuery("#ajax-organizations table tr").each(function() {
		   var arrayOfThisRow = [];
		   var tableData = jQuery(this).find('td');
		   tableData.each(function() {
		     arrayOfThisRow.push(jQuery(this).html());
		   });
		   locations.push(arrayOfThisRow);
	  });
	  locations.reverse();
	  // var centerLatlng = new google.maps.LatLng(locations[0][2], locations[0][3]);
	  var organizations = true;
	}
    var mapOptions = {
	  zoom: 16,
	  center: centerLatlng,
	};
	map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	if(organizations){
	  var bounds = new google.maps.LatLngBounds();
	  for (index in locations) {
	    addMarker(locations[index]);
	    // var data = locations[index];
	    // bounds.extend(new google.maps.LatLng(data[2], data[3]));
	  }
	  /*if(locations.length > 1) {
		myFitBounds(map, bounds);
	  } else {
	    var mapZoom = map.getZoom();
		if(mapZoom && mapZoom < 16){
		  map.setZoom(16);
		}
		map.setCenter(new google.maps.LatLng(locations[0][2], locations[0][3]));
	  }*/
	}

	google.maps.event.addListener(map, 'dragend', function() {
	  if (filterXHR && filterXHR.readyState != 4) {
        // abort ajax request
		filterXHR.abort();
		// subsequent requests will add their own progress indicator,
		// so you probably want to remove the old one here 
		jQuery('.ajax-progress').remove();
	  }
	  var newBounds = map.getBounds();
	  loadMapBounds(newBounds);
	});
	google.maps.event.addListener(map, 'zoom_changed', function() {
	  if (filterXHR && filterXHR.readyState != 4) {
        // abort ajax request
		filterXHR.abort();
		// subsequent requests will add their own progress indicator,
		// so you probably want to remove the old one here 
		jQuery('.ajax-progress').remove();
	  }
	  var newBounds = map.getBounds();
	  loadMapBounds(newBounds);
	});
  }

  function myFitBounds(myMap, bounds) {
	  myMap.fitBounds(bounds);

	  var overlayHelper = new google.maps.OverlayView();
	  overlayHelper.draw = function () {
        if (!this.ready) {
            var zoom = getExtraZoom(this.getProjection(), bounds, myMap.getBounds());
            if (zoom > 0) {
                myMap.setZoom(myMap.getZoom() + zoom);
            }
            this.ready = true;
            google.maps.event.trigger(this, 'ready');
        }
      };

	  overlayHelper.setMap(myMap);  
  }

  // LatLngBounds b1, b2 -> zoom increment
  function getExtraZoom(projection, expectedBounds, actualBounds) {
    var expectedSize = getSizeInPixels(projection, expectedBounds),
        actualSize = getSizeInPixels(projection, actualBounds);

    if (Math.floor(expectedSize.x) == 0 || Math.floor(expectedSize.y) == 0) {
        return 0;
    }

    var qx = actualSize.x / expectedSize.x;
    var qy = actualSize.y / expectedSize.y;
    var min = Math.min(qx, qy);

    if (min < 1) {
        return 0;
    }

    return Math.floor(Math.log(min) / Math.log(2) /* = log2(min) */);
  }

  // LatLngBounds bnds -> height and width as a Point
  function getSizeInPixels(projection, bounds) {
    var sw = projection.fromLatLngToContainerPixel(bounds.getSouthWest());
    var ne = projection.fromLatLngToContainerPixel(bounds.getNorthEast());
    return new google.maps.Point(Math.abs(sw.y - ne.y), Math.abs(sw.x - ne.x));
  }

  function addMarker(data) {
	  var descTitle = data[0] + ' - ' + data[1];
	  var pinType = 'd_map_pin_letter';
	  if(data[0] == '') {
	    descTitle = data[1];
	  } else {
	    zIndex = 100 - data[0];
	  }
	  var image = 'http://chart.apis.google.com/chart?chst='+pinType+'&chld='+data[0]+'|407EC9|FFFFFF';

	  if(zIndex != false){
	    var markers = new google.maps.Marker({
		  position: new google.maps.LatLng(data[2], data[3]),
		  map: map,
		  icon: { url: image },
		  title: descTitle,
		  html: data[4],
		  draggable: false,
		  animation: google.maps.Animation.DROP,
		  zIndex: zIndex,
		  markerId: data[0]
	    });
	  } else {
	    var markers = new google.maps.Marker({
	      position: new google.maps.LatLng(data[2], data[3]),
		  map: map,
		  icon: { url: image },
		  title: descTitle,
		  html: data[4],
		  draggable: false,
		  animation: google.maps.Animation.DROP
	    });
	  }
	  allMarkers.push(markers);
	  google.maps.event.addListener(markers, "click", function() {
	    if(zIndex != false){
		  getHighestZIndex();
		  this.setZIndex(highestZIndex+1);
		}
	    openInfoWindow(markers);
	  });
  }

  function openInfoWindow(markers) {
    title.innerHTML = markers.getTitle();
	info.innerHTML = markers.html;
	infowindow.open(map, markers);
  }

  function getHighestZIndex() {
    if (allMarkers.length>0) {
    for (var i=0; i < allMarkers.length; i++) {
      tempZIndex = allMarkers[i].getZIndex();
      if (tempZIndex>highestZIndex) {
	    highestZIndex = tempZIndex;
	  }
    }
    }
	return highestZIndex;
  }

  // Sets the map on all markers in the array.
  function setAllMap(map) {
    for (var i = 0; i < allMarkers.length; i++) {
	  allMarkers[i].setMap(map);
	}
  }

  function deleteMarker(){
    setAllMap(null);
    allMarkers = [];
  }

  function loadMapBounds(iBounds) {
    var NE = iBounds.getNorthEast();
	var SW = iBounds.getSouthWest();
	var north = NE.lat();
	var east = NE.lng();
	var south = SW.lat();
	var west = SW.lng();

	jQuery("input[name='field_org_latlng_lat[min]']").val(south);
	jQuery("input[name='field_org_latlng_lat[max]']").val(north);
	jQuery("input[name='field_org_latlng_lng[min]']").val(west);
	jQuery("input[name='field_org_latlng_lng[max]']").val(east);
	// jQuery(".view-organizations .views-submit-button .form-submit").trigger("click");
	jQuery("#block-views-exp-organizations-page .views-submit-button .form-submit").trigger("click");
  }

  Drupal.behaviors.YourBehaviour = {
    attach: function(context, settings) {
	  jQuery(document).ajaxSend(function (event, jqXHR, settings) {
	    if(settings.url.indexOf('/views/ajax') == 0){
		  disableHover = true;
	      filterXHR = jqXHR; // cache XHR object for current ajax request
		}
	  });

	  jQuery('.view-id-organizations').unbind('ajaxSuccess').ajaxSuccess(function(event, xhr, settings){
	    if(settings.url.indexOf('/views/ajax') == 0){
		 disableHover = false;
		 locations = [];
		 if(jQuery(".view-empty #ajax-organizations table tr").length > 0){
		 } else {
		  jQuery("#ajax-organizations table tr").each(function() {
		    var arrayOfThisRow = [];
			var tableData = jQuery(this).find('td');
			tableData.each(function() {
			  arrayOfThisRow.push(jQuery(this).html());
			});
			locations.push(arrayOfThisRow);
		  });
		 }
		 deleteMarker();
		 for (index in locations) addMarker(locations[index]);
		}
      });

	  if(!!jQuery('.view-organizations .views-row').offset()){
	    jQuery(".view-organizations .views-row").unbind('hover').hover(function() {
		  if(disableHover){
		  } else {
		    var orgId = jQuery(this).attr("id");
			if (allMarkers.length>0) {
			  for (var i=0; i < allMarkers.length; i++) {
			    console.log(orgId);
			    if(allMarkers[i].markerId){
			      var mId = 'organization-'+allMarkers[i].markerId;
				  console.log(mId);
			      if(mId == orgId){
				    console.log('test');
				    getHighestZIndex();
					allMarkers[i].setZIndex(highestZIndex+1);
					var hoverInIcon = { url: 'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld='+allMarkers[i].markerId+'|F49520|FFFFFF'};
				    allMarkers[i].setIcon(hoverInIcon);
					openInfoWindow(allMarkers[i]);
				  }
				}
			  }
			}
		  }
		}, function() {
		  if(disableHover){
		  } else {
		    var orgId = jQuery(this).attr("id");
			if (allMarkers.length>0) {
			  for (var i=0; i < allMarkers.length; i++) {
			    if(allMarkers[i].markerId){
			      var mId = 'organization-'+allMarkers[i].markerId;
			      if(mId == orgId){
			        var hoverOutIcon = { url: 'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld='+allMarkers[i].markerId+'|407EC9|FFFFFF'};
				    allMarkers[i].setIcon(hoverOutIcon);
				  }
				}
			  }
			}
		  }
		});
	  }
	}
  };

  google.maps.event.addDomListener(window, 'load', initialize);

/*  var map;
  var geocoder;
  var directionsDisplay;
  var directionsService = new google.maps.DirectionsService();
  var markers = [];
  var allMarkers = [];
  var i;
  var m;
  var n = 0;
  var itineraryPoints = [];
  var resetMap;
  var points = false;
  var zoomLoad;
  var zoomLevelSet = false;
  var mapBoundFilter = true;
  var disableHover = false;
  var filterXHR = null;
  var zIndex = false;
  var highestZIndex;
  var tempZIndex;
  var polylineOptionsPlan = {
      strokeColor: '#FF0000',
      strokeOpacity: 0.8,
      strokeWeight: 3
  };
  var featuredLocations = [];
  if (typeof locations !== 'undefined' && locations.length > 0){
    locations.reverse();
    var centerLatlng = new google.maps.LatLng(locations[0][2], locations[0][3]);
	points = true;
  } else {
    var centerLatlng = new google.maps.LatLng(42.3584, -71.0598);
  }
  var content = document.createElement("DIV");
  content.className = "location-details";
  content.style.width="150px";
  var title = document.createElement("DIV");
  title.className = "location-title";
  content.appendChild(title);
  var info = document.createElement("DIV");
  info.className = "location-info";
  content.appendChild(info);
  var infowindow = new google.maps.InfoWindow({
    content: content,
	maxWidth: 150
  });

  function initialize() {
    geocoder = new google.maps.Geocoder();
    directionsDisplay = new google.maps.DirectionsRenderer({suppressMarkers: true, polylineOptions: polylineOptionsPlan}); // Add "preserveViewport: true" to disable zoom.
    if(jQuery("#ajax-itineraries table tr.first").length > 0){
	locations = [];
	jQuery("#ajax-itineraries table tr.first").each(function() {
		   var arrayOfThisRow = [];
		   var tableData = jQuery(this).find('td');
		   tableData.each(function() {
		     arrayOfThisRow.push(jQuery(this).html());
		   });
		   locations.push(arrayOfThisRow);
    });
	points = true;
	locations.reverse();
    var centerLatlng = new google.maps.LatLng(locations[0][2], locations[0][3]);
	}
    var dragBoundary = false;
	var sD = jQuery("input[name='field_itinerary_latitude_value[min]']").val();
	var nD = jQuery("input[name='field_itinerary_latitude_value[max]']").val();
	var wD = jQuery("input[name='field_itinerary_longitude_value[min]']").val();
	var eD = jQuery("input[name='field_itinerary_longitude_value[max]']").val();
	if (typeof nD !== 'undefined' && typeof eD !== 'undefined' && typeof sD !== 'undefined' && typeof wD !== 'undefined'){
	  if(nD.length > 0 && eD.length > 0 && sD.length > 0 && wD.length > 0) {
	    dragBoundary = true;
	  }
	}

	if(dragBoundary == false && Drupal.settings.localnav.zoom != false) {
      var mapOptions = {
	    zoom: Drupal.settings.localnav.zoom,
		center: centerLatlng,
	    mapTypeId: google.maps.MapTypeId.ROADMAP,
		scrollwheel: false,
	  };
    } else {
	  var mapOptions = {
		// center: centerLatlng,
	    mapTypeId: google.maps.MapTypeId.ROADMAP,
		scrollwheel: false,
	  };
	}
	map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	directionsDisplay.setMap(map);

	if(points) for (index in locations) addMarker(locations[index]);

	var zoomLevel = 12;
	if(window.location.href.indexOf('&zoom') >= 0){
	  var zoomQuery = window.location.href.slice(window.location.href.indexOf('&zoom') + 1).split('=');
	  zoomLevel = (zoomQuery[1]) ? parseInt(zoomQuery[1]): zoomLevel;
	  zoomLevelSet = (zoomQuery[1]) ? parseInt(zoomQuery[1]) : false;
	}
	
	// If lat & long set through dragged map.
	if(dragBoundary == true) {
	  var nE = new google.maps.LatLng(nD, eD);
	  var sW = new google.maps.LatLng(sD, wD);
	  var bounds = new google.maps.LatLngBounds(sW, nE);

	  mapBoundFilter = false;
	  // map.fitBounds(bounds);
	  myFitBounds(map, bounds);
	}

	if(Drupal.settings.localnav.zoom == false && points == true && dragBoundary == false) {
	  var bounds = new google.maps.LatLngBounds();
	  for (index in locations) {
	    var data = locations[index];
	    bounds.extend(new google.maps.LatLng(data[2], data[3]));
	  }
	  map.setZoom(zoomLevel);
	  map.setCenter(bounds.getCenter());
	}
	
	google.maps.event.addListener(map, 'dragend', function() {
	  var newBounds = map.getBounds();
	  if(jQuery('#map-form input').is(':checked') && mapBoundFilter == true){
		loadItineraries(newBounds);
	  }
	  mapBoundFilter = true;
	});
	google.maps.event.addListener(map, 'zoom_changed', function() {
	  if(jQuery('#map-form input').is(':checked') && mapBoundFilter == true){
	  if (filterXHR && filterXHR.readyState != 4) {
	    // abort ajax request
		filterXHR.abort();
		// subsequent requests will add their own progress indicator,
		// so you probably want to remove the old one here 
		jQuery('.ajax-progress').remove();
	  }
	  var newBounds = map.getBounds();
	  
		loadItineraries(newBounds);
	  }
	  mapBoundFilter = true;
	});

	google.maps.event.addListenerOnce( map, 'idle', function() {
	  var currentZoom = map.getZoom();
	  if(zoomLevelSet && (zoomLevelSet != currentZoom)){
	    map.setZoom(zoomLevelSet);
	  } else {
	    var newBounds = map.getBounds();
	    if(jQuery('#map-form input').is(':checked') && mapBoundFilter == true){
		  loadItineraries(newBounds);
	    }
	    mapBoundFilter = true;
	  }
	});

  }


  function myFitBounds(myMap, bounds) {
	mapBoundFilter = false;
    myMap.fitBounds(bounds);

	mapBoundFilter = false;
    var overlayHelper = new google.maps.OverlayView();
    overlayHelper.draw = function () {
        if (!this.ready) {
            var zoom = getExtraZoom(this.getProjection(), bounds, myMap.getBounds());
            if (zoom > 0) {
				mapBoundFilter = false;
                myMap.setZoom(myMap.getZoom() + zoom);
            }
            this.ready = true;
			mapBoundFilter = false;
            google.maps.event.trigger(this, 'ready');
        }
    };
	mapBoundFilter = false;
    overlayHelper.setMap(myMap);  
}

// LatLngBounds b1, b2 -> zoom increment
function getExtraZoom(projection, expectedBounds, actualBounds) {
    var expectedSize = getSizeInPixels(projection, expectedBounds),
        actualSize = getSizeInPixels(projection, actualBounds);

    if (Math.floor(expectedSize.x) == 0 || Math.floor(expectedSize.y) == 0) {
        return 0;
    }

    var qx = actualSize.x / expectedSize.x;
    var qy = actualSize.y / expectedSize.y;
    var min = Math.min(qx, qy);

    if (min < 1) {
        return 0;
    }

    return Math.floor(Math.log(min) / Math.log(2));
}

// LatLngBounds bnds -> height and width as a Point
function getSizeInPixels(projection, bounds) {
    var sw = projection.fromLatLngToContainerPixel(bounds.getSouthWest());
    var ne = projection.fromLatLngToContainerPixel(bounds.getNorthEast());
    return new google.maps.Point(Math.abs(sw.y - ne.y), Math.abs(sw.x - ne.x));
}

  function calcRoute(lastIndex) {
	var start = new google.maps.LatLng(itineraryPoints[0][2], itineraryPoints[0][3]);
    var end = new google.maps.LatLng(itineraryPoints[lastIndex][2], itineraryPoints[lastIndex][3]);
	var waypts = [];
	var maxWayPts = itineraryPoints.length - 2;
	if(maxWayPts > 9){
	  maxWayPts = 9;
	}
	for (var i = 1; i < maxWayPts; i++) {
	  waypts.push({
	    location:new google.maps.LatLng(itineraryPoints[i][2], itineraryPoints[i][3]),
	    stopover:true
	  });
	}
	var modeOfTravel = itineraryPoints[0][6];
	if (typeof modeOfTravel !== 'undefined' && modeOfTravel.length > 0){
	  if(modeOfTravel == 'DRIVING'){
	    modeOfTravel = google.maps.DirectionsTravelMode.DRIVING;
	  }
	  // Waypoint does not support Public transport so as fallback use driving.
	  if(modeOfTravel == 'TRANSIT'){
	    modeOfTravel = google.maps.DirectionsTravelMode.DRIVING;
	  }
	  if(modeOfTravel == 'WALKING'){
	    modeOfTravel = google.maps.DirectionsTravelMode.WALKING;
	  }
	} else {
	  var modeOfTravel = google.maps.DirectionsTravelMode.DRIVING;
	}

    var request = {
      origin:start,
      destination:end,
	  waypoints: waypts,
      travelMode: modeOfTravel
    };
    directionsService.route(request, function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
	    // To make sure the mapBoundFilter is false
	    mapBoundFilter = false;
		directionsDisplay.setMap(map);
        directionsDisplay.setDirections(response);
      }
    });
  }
  
  function addMarker(data) {
	  var descTitle = data[0] + ' - ' + data[1];
	  var pinType = 'd_map_pin_letter';
	  if(data[0] == '') {
	    descTitle = data[1];
		//data[0] = 'star';
		//pinType = 'd_map_pin_icon';
	  } else {
	    zIndex = 100 - data[0];
	  }
	  var image = 'http://chart.apis.google.com/chart?chst='+pinType+'&chld='+data[0]+'|25AAE1|FFFFFF';
	  if(data[5] == 1) {
	    image = 'http://chart.apis.google.com/chart?chst='+pinType+'&chld='+data[0]+'|FFAB58|000000';
	  }
	  if(zIndex != false){
	    var markers = new google.maps.Marker({
		  position: new google.maps.LatLng(data[2], data[3]),
		  map: map,
		  icon: image,
		  title: descTitle,
		  html: data[4],
		  draggable: false,
		  animation: google.maps.Animation.DROP,
		  zIndex: zIndex
	    });
	  } else {
	    var markers = new google.maps.Marker({
	      position: new google.maps.LatLng(data[2], data[3]),
		  map: map,
		  icon: image,
		  title: descTitle,
		  html: data[4],
		  draggable: false,
		  animation: google.maps.Animation.DROP
	    });
	  }
	  allMarkers.push(markers);
	  google.maps.event.addListener(markers, "click", function() {
	    if(zIndex != false){
		  getHighestZIndex();
		  this.setZIndex(highestZIndex+1);
		}
	    openInfoWindow(markers);
	  });
      n++;
    }

  function openInfoWindow(markers) {
    title.innerHTML = markers.getTitle();
	info.innerHTML = markers.html;
	infowindow.open(map, markers);
  }

  function getHighestZIndex() {
    if (allMarkers.length>0) {
    for (var i=0; i < allMarkers.length; i++) {
      tempZIndex = allMarkers[i].getZIndex();
      if (tempZIndex>highestZIndex) {
	    highestZIndex = tempZIndex;
	  }
    }
    }
	return highestZIndex;
  }
  // Sets the map on all markers in the array.
  function setAllMap(map) {
    for (var i = 0; i < allMarkers.length; i++) {
	  allMarkers[i].setMap(map);
	}
  }

  function deleteMarker(){
    setAllMap(null);
	directionsDisplay.setMap(null);
    allMarkers = [];
  }

  Drupal.behaviors.YourBehaviour = {
    attach: function(context, settings) {
	  jQuery(document).ajaxSend(function (event, jqXHR, settings) {
	    if(settings.url.indexOf('/views/ajax') == 0){
		  disableHover = true; // set as true - to disable hovering effect over itinerary listing when views ajax is executing.
	      filterXHR = jqXHR; // cache XHR object for current ajax request
		}
	  });
	  jQuery('.view-id-itineraries, .view-id-itineraries_map, .view-id-itinerary_search').unbind('ajaxStart').ajaxStart(function(event, xhr, settings){
          jQuery('.view-itineraries .view-content, .view-itineraries-map .view-content, .view-itinerary-search .view-content').fadeTo(300, 0.5);
      });
	  if(jQuery(".view-itineraries .views-row").length > 0 || jQuery(".view-itinerary-search .views-row").length > 0 || jQuery(".view-itineraries-map .views-view-grid td").length > 0){
	    jQuery(".view-itineraries .views-row, .view-itinerary-search .views-row, .view-itineraries-map .views-view-grid td").unbind('hover').hover(function() {
		  if(disableHover){
		  } else {
		  mapBoundFilter = false;
		  clearTimeout(resetMap);
		  itineraryPoints = [];
		  var itineraryNumber = jQuery(this).find('.views-field-counter .field-content').text();
		  jQuery("#ajax-itineraries table#itinerary-"+itineraryNumber+" tr").each(function(){
		    var arrayOfThisRow = [];
		    var tableData = jQuery(this).find('td');
		    tableData.each(function() {
		      arrayOfThisRow.push(jQuery(this).html());
		    });
		    itineraryPoints.push(arrayOfThisRow);
		  });
		  mapBoundFilter = false;
		  deleteMarker();
		  addMarker(itineraryPoints[0]);
		  if(itineraryPoints.length > 1) {
		    calcRoute(itineraryPoints.length-1);
		  } else {
		    var mapZoom = map.getZoom();
		    if(mapZoom && mapZoom < 16){
		     map.setZoom(16);
		    }
		    map.setCenter(new google.maps.LatLng(itineraryPoints[0][2], itineraryPoints[0][3]));
			
		  }
		  }
		}, function() {
		  if(disableHover){
		  } else {
		  resetMap = setTimeout(function(){
		    mapBoundFilter = false;
		    deleteMarker();
		    for (index in locations) addMarker(locations[index]);
			var sD = jQuery("input[name='field_itinerary_latitude_value[min]']").val();
			var nD = jQuery("input[name='field_itinerary_latitude_value[max]']").val();
			var wD = jQuery("input[name='field_itinerary_longitude_value[min]']").val();
			var eD = jQuery("input[name='field_itinerary_longitude_value[max]']").val();
			if (typeof nD !== 'undefined' && typeof eD !== 'undefined' && typeof sD !== 'undefined' && typeof wD !== 'undefined'){
			  if(nD.length > 0 && eD.length > 0 && sD.length > 0 && wD.length > 0) {
			    var nE = new google.maps.LatLng(nD, eD);
				var sW = new google.maps.LatLng(sD, wD);
				var bounds = new google.maps.LatLngBounds(sW, nE);
				mapBoundFilter = false;
				myFitBounds(map, bounds);
			  }
			}
		  }, 1000);
		  }
		});
	  }

	  // Featured on
	  if(jQuery(".view-featured-itineraries .views-row").length > 0){
	    jQuery(".view-featured-itineraries .views-row").unbind('hover').hover(function() {
		  if(disableHover){
		  } else {
		  mapBoundFilter = false;
		  clearTimeout(resetMap);
		  itineraryPoints = [];
		  var itineraryNumber = jQuery(this).find('.views-field-counter .field-content').text();
		  jQuery("#featured-itineraries table#featured-itinerary-"+itineraryNumber+" tr").each(function(){
		    var arrayOfThisRow = [];
		    var featuredTableData = jQuery(this).find('td');
		    featuredTableData.each(function() {
		      arrayOfThisRow.push(jQuery(this).html());
		    });
		    itineraryPoints.push(arrayOfThisRow);
		  });
		  mapBoundFilter = false;
		  deleteMarker();
		  addMarker(itineraryPoints[0]);
		  calcRoute(itineraryPoints.length-1);
		  }
		}, function() {
		  if(disableHover){
		  } else {
		  resetMap = setTimeout(function(){
		    mapBoundFilter = false;
		    deleteMarker();
		    for (index in locations) addMarker(locations[index]);
			var sD = jQuery("input[name='field_itinerary_latitude_value[min]']").val();
			var nD = jQuery("input[name='field_itinerary_latitude_value[max]']").val();
			var wD = jQuery("input[name='field_itinerary_longitude_value[min]']").val();
			var eD = jQuery("input[name='field_itinerary_longitude_value[max]']").val();
			if (typeof nD !== 'undefined' && typeof eD !== 'undefined' && typeof sD !== 'undefined' && typeof wD !== 'undefined'){
			  if(nD.length > 0 && eD.length > 0 && sD.length > 0 && wD.length > 0) {
			    var nE = new google.maps.LatLng(nD, eD);
				var sW = new google.maps.LatLng(sD, wD);
				var bounds = new google.maps.LatLngBounds(sW, nE);
				mapBoundFilter = false;
				myFitBounds(map, bounds);
			  }
			}
		  }, 1000);
		  }
		});
	  }

	  jQuery('.view-id-itineraries, .view-id-itineraries_map, .view-id-itinerary_search').unbind('ajaxSuccess').ajaxSuccess(function(event, xhr, settings){
	    jQuery('.view-itineraries .view-content, .view-itineraries-map .view-content, .view-itinerary-search .view-content').fadeTo(300, 1.0);
		disableHover = false;
	    if(settings.url.indexOf('/views/ajax') == 0){

		 locations = [];
		 if(jQuery(".view-empty #ajax-itineraries table tr").length > 0){
		 } else {
		 jQuery("#ajax-itineraries table tr.first").each(function() {
		   var arrayOfThisRow = [];
		   var tableData = jQuery(this).find('td');
		   tableData.each(function() {
		     arrayOfThisRow.push(jQuery(this).html());
		   });
		   locations.push(arrayOfThisRow);
		 });

		 jQuery(".switch-view a").each(function(){
		   var mapZoom = map.getZoom();
		   if(mapZoom){
		     var href = jQuery(this).attr('href').split('&zoom=')[0];
		     jQuery(this).attr('href', href+'&zoom='+mapZoom);
		   }
		 });
		 }
		 deleteMarker();
		 for (index in locations) addMarker(locations[index]);
		 //alert(myTableArray[0][2]);
		}
      });
	}
  };
  
  function loadItineraries(iBounds) {
    var NE = iBounds.getNorthEast();
	var SW = iBounds.getSouthWest();

	var north = NE.lat();
	var east = NE.lng();
	var south = SW.lat();
	var west = SW.lng();

	jQuery("input[name='field_itinerary_latitude_value[min]']").val(south);
	jQuery("input[name='field_itinerary_latitude_value[max]']").val(north);
	jQuery("input[name='field_itinerary_longitude_value[min]']").val(west);
	jQuery("input[name='field_itinerary_longitude_value[max]']").val(east);
	jQuery("input[name='field_itinerary_latitude_value[min]'], input[name='field_itinerary_latitude_value[max]'], input[name='field_itinerary_longitude_value[min]'], input[name='field_itinerary_longitude_value[max]']").change();
	//zoomLoad = window.clearInterval(zoomLoad);
  }

  google.maps.event.addDomListener(window, 'load', initialize);
*/