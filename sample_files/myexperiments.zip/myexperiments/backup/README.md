# recent_tweets
Pulls the recent tweets and display it rotationally.
